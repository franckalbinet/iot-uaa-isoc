void *FTPLoop( void *some_void_ptr );
