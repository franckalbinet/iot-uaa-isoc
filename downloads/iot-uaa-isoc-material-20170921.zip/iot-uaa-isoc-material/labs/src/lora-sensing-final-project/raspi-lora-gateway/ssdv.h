void *SSDVLoop( void *some_void_ptr );

