#ifndef _GUI_H
#define _GUI_H

#include <ncurses.h>

void gui_show_help ();

#endif
