char *url_encode( char *str );

