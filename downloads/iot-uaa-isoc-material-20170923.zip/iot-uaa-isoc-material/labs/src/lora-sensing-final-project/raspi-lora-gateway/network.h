void *NetworkLoop( void *some_void_ptr );
